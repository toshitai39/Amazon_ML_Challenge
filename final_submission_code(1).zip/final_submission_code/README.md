## To get the desired output we need to run the inference using internlm_v2_8b

To run the inference using internlm_v2_8b, we need to run the following command:
```bash
git clone https://github.com/InternLM/lmdeploy.git
cd lmdeploy
pip install -r requirements.txt
```

After installing the requirements, we can run the inference using the python script `internlm_v2_8b_inferencing`

To finetune the model use the readme given in the finetune folder.

Load the test dataset in the `train.json` file created in the finetune folder.

To get the inference from the finetuned model
```bash
llamafactory-cli train finetune_inference.json
```

After this a folder will be created in the LLaMa factory directory containg all the predictions in json format.

Use the post processing script to get the final output.