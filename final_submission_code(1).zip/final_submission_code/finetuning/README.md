## Finetuning using LLaMa Factory

This folder contains the code to finetune a model using the LLaMA Factory. The LLaMA Factory is a tool that allows you to finetune a model on a specific task using a dataset of your choice. The LLaMA Factory is built on top of the Hugging Face Transformers library and provides a simple interface to finetune a model on a task.

### Steps to Finetune

First clone the LLaMA Factory repository by running the following command:

```bash
git clone https://github.com/hiyouga/LLaMA-Factory.git
```

Next, navigate to the `LLaMA-Factory` directory and install the required dependencies by running the following command:

```bash
pip install -r requirements.txt 
pip install bitsandbytes 
pip install git+https://github.com/huggingface/transformers.git 
pip install -e ".[torch, metrics]" 
pip install liger-kernel
```

Copy the files in this directory to the `LLaMA-Factory` directory.

To add the dataset to the LLaMA Factory, you need to create a dataset configuration file. The dataset configuration file is a JSON file that contains information about the dataset, such as the name of the dataset, the path to the training data, the path to the validation data, and the path to the test data. You can create a dataset configuration file by running the following command:

For this make a json file using the python script `make_dataset_config.py`

Then add the json to the `/data/dataset_info.json` file.

```json
"aml": {
    "file_name": "path_to_the_json_file",
    "formatting": "sharegpt",
    "columns": {
      "messages": "messages",
      "images": "images"
    },
    "tags": {
      "role_tag": "role",
      "content_tag": "content",
      "user_tag": "user",
      "assistant_tag": "assistant"
    }
  }
  ```

Start the training process using the following command:

```bash
llamafactory-cli train train_qwen2vl.json
```

This will save the finetuned model in the `qwen2_vl_lora` directory. Then we will merge the lora adapter with the original model to get the final model.

```bash
llamafactory-cli export merge_lora_model.json
```

This will save the final model in the `qwen2vl_7b_instruct_lora_merged` directory.

